# REVIEW_PACKET

## 1. Run metadata

- 当前工作目录: `/opt/tiger/coding-agent-synth-data/kb-rb-probing`
- git commit hash: `e27a17569c98e9252603e44a9f75c1d2e422b0f0`
- 模型路径: `/opt/tiger/coding-agent-synth-data/Qwen3-8B`
- 主要输入数据路径: `data/probe_ready_180_paired.jsonl`, `data/gpt_test.jsonl`, `data/probe_ready_180_paired_mcq.jsonl` (如存在)
- 主要输出路径: `outputs/first_pass_probing`, `reports/probing_comparison_report.md`
- 运行时间: unknown (缺少明确 duration；mtime: run_index=2026-04-26 13:16:06, report=2026-04-26 13:16:06)
- Python / torch / transformers / sklearn 版本: Python 3.12.11, torch 2.9.0+cu128, transformers 4.57.3, sklearn 1.5.2

## 2. Dataset overview

### probe_ready
- n_families: 180
- task_family 分布: Hybrid:60, KB:60, RB:60
- mode 分布: naturalized:90, strict_symbolic:90
- sub_family 缺失数: 0
- variant coverage: competing_claims:180, highlight:180, hint:180, original:180, paraphrase:180, premise:180, premise_removal:180, scaffold_1:180, scaffold_2:180, wrongclaim_bare:180
- MCQ 是否存在: no
- validation report 是否 issues=[]: yes (reports/probe_ready_validation_report.json)
### gpt_test
- n_families: 180
- task_family 分布: Hybrid:60, KB:60, RB:60
- mode 分布: naturalized:90, strict_symbolic:90
- sub_family 缺失数: 60
- variant coverage: competing_claims:180, highlight:180, hint:180, original:180, paraphrase:180, premise:180, premise_removal:180, scaffold_1:180, scaffold_2:180, wrongclaim_bare:180
- MCQ 是否存在: no
- validation report 是否 issues=[]: unknown (no_report)
### probe_ready_mcq
- n_families: 90
- task_family 分布: Hybrid:30, KB:30, RB:30
- mode 分布: strict_symbolic:90
- sub_family 缺失数: 0
- variant coverage: original:90
- MCQ 是否存在: yes
- validation report 是否 issues=[]: yes (reports/probe_ready_validation_report_mcq.json)

## 3. Label distribution summary

### probe_ready
- wrong_claim_susceptible: pos_count=48, neg_count=132, degenerate=no, severe_imbalance=no
  - pos/neg by task_family: pos[RB:21, KB:17, Hybrid:10] | neg[Hybrid:50, KB:43, RB:39]
  - pos/neg by mode: pos[naturalized:32, strict_symbolic:16] | neg[strict_symbolic:74, naturalized:58]
- removal_dependent: pos_count=179, neg_count=1, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[Hybrid:60, KB:60, RB:59] | neg[RB:1]
  - pos/neg by mode: pos[strict_symbolic:90, naturalized:89] | neg[naturalized:1]
- premise_sensitive: pos_count=48, neg_count=132, degenerate=no, severe_imbalance=no
  - pos/neg by task_family: pos[RB:26, KB:18, Hybrid:4] | neg[Hybrid:56, KB:42, RB:34]
  - pos/neg by mode: pos[strict_symbolic:40, naturalized:8] | neg[naturalized:82, strict_symbolic:50]
- scaffold_sensitive: pos_count=162, neg_count=18, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[Hybrid:59, KB:52, RB:51] | neg[RB:9, KB:8, Hybrid:1]
  - pos/neg by mode: pos[naturalized:88, strict_symbolic:74] | neg[strict_symbolic:16, naturalized:2]
- paraphrase_fragile: pos_count=102, neg_count=78, degenerate=no, severe_imbalance=no
  - pos/neg by task_family: pos[KB:37, RB:36, Hybrid:29] | neg[Hybrid:31, RB:24, KB:23]
  - pos/neg by mode: pos[naturalized:86, strict_symbolic:16] | neg[strict_symbolic:74, naturalized:4]
- localization_sensitive: pos_count=169, neg_count=11, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[KB:60, Hybrid:59, RB:50] | neg[RB:10, Hybrid:1]
  - pos/neg by mode: pos[naturalized:87, strict_symbolic:82] | neg[strict_symbolic:8, naturalized:3]
- decomposition_sensitive: pos_count=162, neg_count=18, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[Hybrid:59, KB:52, RB:51] | neg[RB:9, KB:8, Hybrid:1]
  - pos/neg by mode: pos[naturalized:88, strict_symbolic:74] | neg[strict_symbolic:16, naturalized:2]
- lexical_fragile: pos_count=102, neg_count=78, degenerate=no, severe_imbalance=no
  - pos/neg by task_family: pos[KB:37, RB:36, Hybrid:29] | neg[Hybrid:31, RB:24, KB:23]
  - pos/neg by mode: pos[naturalized:86, strict_symbolic:16] | neg[strict_symbolic:74, naturalized:4]
### gpt_test
- wrong_claim_susceptible: pos_count=37, neg_count=143, degenerate=no, severe_imbalance=no
  - pos/neg by task_family: pos[KB:19, Hybrid:9, RB:9] | neg[Hybrid:51, RB:51, KB:41]
  - pos/neg by mode: pos[strict_symbolic:25, naturalized:12] | neg[naturalized:78, strict_symbolic:65]
- removal_dependent: pos_count=96, neg_count=84, degenerate=no, severe_imbalance=no
  - pos/neg by task_family: pos[KB:41, Hybrid:34, RB:21] | neg[RB:39, Hybrid:26, KB:19]
  - pos/neg by mode: pos[strict_symbolic:59, naturalized:37] | neg[naturalized:53, strict_symbolic:31]
- premise_sensitive: pos_count=166, neg_count=14, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[RB:57, Hybrid:56, KB:53] | neg[KB:7, Hybrid:4, RB:3]
  - pos/neg by mode: pos[strict_symbolic:89, naturalized:77] | neg[naturalized:13, strict_symbolic:1]
- scaffold_sensitive: pos_count=176, neg_count=4, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[KB:60, Hybrid:58, RB:58] | neg[Hybrid:2, RB:2]
  - pos/neg by mode: pos[strict_symbolic:90, naturalized:86] | neg[naturalized:4]
- paraphrase_fragile: pos_count=176, neg_count=4, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[KB:60, Hybrid:59, RB:57] | neg[RB:3, Hybrid:1]
  - pos/neg by mode: pos[strict_symbolic:89, naturalized:87] | neg[naturalized:3, strict_symbolic:1]
- localization_sensitive: pos_count=152, neg_count=28, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[RB:56, Hybrid:52, KB:44] | neg[KB:16, Hybrid:8, RB:4]
  - pos/neg by mode: pos[strict_symbolic:84, naturalized:68] | neg[naturalized:22, strict_symbolic:6]
- decomposition_sensitive: pos_count=176, neg_count=4, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[KB:60, Hybrid:58, RB:58] | neg[Hybrid:2, RB:2]
  - pos/neg by mode: pos[strict_symbolic:90, naturalized:86] | neg[naturalized:4]
- lexical_fragile: pos_count=176, neg_count=4, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[KB:60, Hybrid:59, RB:57] | neg[RB:3, Hybrid:1]
  - pos/neg by mode: pos[strict_symbolic:89, naturalized:87] | neg[naturalized:3, strict_symbolic:1]
### probe_ready_mcq
- wrong_claim_susceptible: pos_count=16, neg_count=74, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[KB:8, RB:8] | neg[Hybrid:30, KB:22, RB:22]
  - pos/neg by mode: pos[strict_symbolic:16] | neg[strict_symbolic:74]
- removal_dependent: pos_count=90, neg_count=0, degenerate=yes, severe_imbalance=yes
  - pos/neg by task_family: pos[Hybrid:30, KB:30, RB:30] | neg[(empty)]
  - pos/neg by mode: pos[strict_symbolic:90] | neg[(empty)]
- premise_sensitive: pos_count=40, neg_count=50, degenerate=no, severe_imbalance=no
  - pos/neg by task_family: pos[RB:22, KB:16, Hybrid:2] | neg[Hybrid:28, KB:14, RB:8]
  - pos/neg by mode: pos[strict_symbolic:40] | neg[strict_symbolic:50]
- scaffold_sensitive: pos_count=74, neg_count=16, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[Hybrid:30, KB:22, RB:22] | neg[KB:8, RB:8]
  - pos/neg by mode: pos[strict_symbolic:74] | neg[strict_symbolic:16]
- paraphrase_fragile: pos_count=16, neg_count=74, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[KB:8, RB:8] | neg[Hybrid:30, KB:22, RB:22]
  - pos/neg by mode: pos[strict_symbolic:16] | neg[strict_symbolic:74]
- localization_sensitive: pos_count=82, neg_count=8, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[Hybrid:30, KB:30, RB:22] | neg[RB:8]
  - pos/neg by mode: pos[strict_symbolic:82] | neg[strict_symbolic:8]
- decomposition_sensitive: pos_count=74, neg_count=16, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[Hybrid:30, KB:22, RB:22] | neg[KB:8, RB:8]
  - pos/neg by mode: pos[strict_symbolic:74] | neg[strict_symbolic:16]
- lexical_fragile: pos_count=16, neg_count=74, degenerate=no, severe_imbalance=yes
  - pos/neg by task_family: pos[KB:8, RB:8] | neg[Hybrid:30, KB:22, RB:22]
  - pos/neg by mode: pos[strict_symbolic:16] | neg[strict_symbolic:74]

## 4. Metadata-only baseline summary

- 约束: metadata-only classifier **只允许**使用 `task_family / sub_family / mode / answer_type`。
- 说明: 本包中的 metadata-only 结果由 handoff 脚本计算（不重跑模型、只读现有 json/jsonl）；repo 内未发现独立的 metadata-only classifier 输出目录，因此“实际代码是否使用了额外字段”标为 unknown。

- wrong_claim_susceptible: metadata_only_f1_probe_ready=0.6883 (std=0.0000), metadata_only_f1_gpt_test=0.4316 (std=0.0000)
  - 是否 >= 0.70: probe_ready=no, gpt_test=no
  - 用了哪些 metadata features: task_family, sub_family, mode, answer_type
- removal_dependent: metadata_only_f1_probe_ready=unknown (std=unknown), metadata_only_f1_gpt_test=0.7221 (std=0.0000)
  - 是否 >= 0.70: probe_ready=no, gpt_test=yes
  - 用了哪些 metadata features: task_family, sub_family, mode, answer_type
- premise_sensitive: metadata_only_f1_probe_ready=0.7879 (std=0.0000), metadata_only_f1_gpt_test=0.5849 (std=0.0000)
  - 是否 >= 0.70: probe_ready=yes, gpt_test=no
  - 用了哪些 metadata features: task_family, sub_family, mode, answer_type
- scaffold_sensitive: metadata_only_f1_probe_ready=0.8699 (std=0.0000), metadata_only_f1_gpt_test=0.4857 (std=0.0000)
  - 是否 >= 0.70: probe_ready=yes, gpt_test=no
  - 用了哪些 metadata features: task_family, sub_family, mode, answer_type
- paraphrase_fragile: metadata_only_f1_probe_ready=0.7962 (std=0.0000), metadata_only_f1_gpt_test=unknown (std=unknown)
  - 是否 >= 0.70: probe_ready=yes, gpt_test=no
  - 用了哪些 metadata features: task_family, sub_family, mode, answer_type
- localization_sensitive: metadata_only_f1_probe_ready=0.6158 (std=0.0000), metadata_only_f1_gpt_test=0.5210 (std=0.0000)
  - 是否 >= 0.70: probe_ready=no, gpt_test=no
  - 用了哪些 metadata features: task_family, sub_family, mode, answer_type
- decomposition_sensitive: metadata_only_f1_probe_ready=0.8699 (std=0.0000), metadata_only_f1_gpt_test=0.4857 (std=0.0000)
  - 是否 >= 0.70: probe_ready=yes, gpt_test=no
  - 用了哪些 metadata features: task_family, sub_family, mode, answer_type
- lexical_fragile: metadata_only_f1_probe_ready=0.7962 (std=0.0000), metadata_only_f1_gpt_test=unknown (std=unknown)
  - 是否 >= 0.70: probe_ready=yes, gpt_test=no
  - 用了哪些 metadata features: task_family, sub_family, mode, answer_type

## 5. Third-pass key comparison

- wrong_claim_susceptible: best hidden transfer setting=held_out_sub_family::country_capital; feature_name=h_original; feature_mode=absolute; position=pre_answer; layer=1; hidden_f1=1.0000; metadata_f1=0.4589; hidden_minus_metadata=0.5411; train pos/neg=47/117; test pos/neg=1/15
- removal_dependent: best hidden transfer setting=block::train_RB__test_Hybrid; feature_name=h_original; feature_mode=absolute; position=final_input; layer=2; hidden_f1=0.7128; metadata_f1=0.3304; hidden_minus_metadata=0.3824; train pos/neg=21/39; test pos/neg=34/26
- paraphrase_fragile: best hidden transfer setting=train_gpt_test__test_probe_ready::paraphrase_fragile::final_input; feature_name=h_original; feature_mode=absolute; position=final_input; layer=0; hidden_f1=0.8444; metadata_f1=0.3617; hidden_minus_metadata=0.4827; train pos/neg=176/4; test pos/neg=102/78
- premise_sensitive: best hidden transfer setting=held_out_sub_family::retrieve_transform; feature_name=h_original; feature_mode=absolute; position=pre_answer; layer=4; hidden_f1=1.0000; metadata_f1=0.4839; hidden_minus_metadata=0.5161; train pos/neg=47/117; test pos/neg=1/15
- scaffold_sensitive: best hidden transfer setting=held_out_sub_family::function_application; feature_name=h_original; feature_mode=absolute; position=pre_answer; layer=24; hidden_f1=1.0000; metadata_f1=0.2941; hidden_minus_metadata=0.7059; train pos/neg=151/17; test pos/neg=11/1

(其余 labels 见 CSV。)

## 6. Implementation sanity checklist

- split 是否 family-level: yes (run_first_pass_probing.py:966 (stratified_random_split) / :982 (held_out_subfamily_splits) / :997 (block_level_splits))
- 同一个 family 的 variants 是否没有跨 train/test 泄漏: yes (split 使用 family_id 列表；run_layerwise_probe 仅按同一 fid 取 variant / delta (run_first_pass_probing.py:1099))
- atomic labels 是否从 behavior score delta 生成: yes (run_first_pass_probing.py:903 (compute_signals_for_family + label_to_signal + extreme_bin_labels))
- metadata-only classifier 是否没有使用 label/signal/variant/prompt/gold/model output/hidden state: unknown (repo 内未发现独立 metadata-only classifier 实现/输出；本包 handoff baseline 仅用 4 个字段)
- delta feature 是否是同一个 family 内 h_variant - h_original: yes (run_first_pass_probing.py:1091 (def delta: return v1 - v0))
- hidden state 抽取是否没有把 gold answer 拼进 input: unknown (需检查 hidden-state prompt 构造代码路径)
- cross_dataset_transfer_v2 是否比旧 cross_dataset_transfer 更可信: unknown (v2 使用 prefix family_id + 阈值对齐；见 run_first_pass_probing.py:1810)
- MCQ transfer 是否已排除主结论: unknown (CSV 中 mcq_transfer rows 标记 is_mcq=true；是否进入结论需人工确认)
- random split 是否只作为 sanity: unknown (CSV 中 random_family_split 标记 is_random_split=true；脚本报告生成使用范围需人工确认)

## 7. Relevant code snippets

### atomic label derivation
- source: `run_first_pass_probing.py` (around line 889)
```
889:         elif v <= neg_thr:
890:             labels[fid] = 0
891:         else:
892:             labels[fid] = None
893:     return pos_thr, neg_thr, labels
894: 
895: 
896: def build_atomic_labels(
897:     families: list[Family],
898:     scores: dict[str, dict[str, VariantResult]],
899:     top_q: float,
900:     dataset_tag: str,
901: ) -> dict[str, Any]:
902:     # per-family signal table
903:     fam_signals: dict[str, dict[str, float | None]] = {}
904:     for f in families:
905:         sm = {k: float(v.score) for k, v in scores.get(f.family_id, {}).items()}
906:         fam_signals[f.family_id] = compute_signals_for_family(sm)
907: 
908:     # label -> signal_name mapping
909:     label_to_signal = {
910:         "premise_sensitive": "premise_gain",
911:         "removal_dependent": "removal_drop",
912:         "wrong_claim_susceptible": "wrongclaim_drop",
913:         "scaffold_sensitive": "scaffold_gain",
914:         "paraphrase_fragile": "paraphrase_drop",
915:         "substitution_fragile": "substitution_drop",
916:         # extra
917:         "access_sensitive": "removal_drop",
918:         "localization_sensitive": "highlight_delta",
919:         "integration_sensitive": "full_support_bundle_gain",  # likely missing
920:         "decomposition_sensitive": "scaffold_gain",
921:         "order_sensitive": "order_delta",  # missing
922:         "intermediate_state_sensitive": "cot_delta",  # missing
923:         "cue_susceptible": "wrongclaim_drop",
924:         "authority_susceptible": "authority_drop",  # missing
925:         "conflict_resolution_weak": "conflict_drop",
926:         "lexical_fragile": "paraphrase_drop",
927:         "terminology_fragile": "terminology_drop",  # missing
928:         "structure_misaligned": "substitution_drop",
929:     }
930: 
931:     labels_out: dict[str, Any] = {}
932:     unusable: dict[str, str] = {}
933:     for lab, sig_name in label_to_signal.items():
934:         # collect available signals
935:         sigs: dict[str, float] = {}
936:         for fid, sd in fam_signals.items():
937:             v = sd.get(sig_name)
938:             if isinstance(v, (int, float)) and not math.isnan(float(v)):
939:                 sigs[fid] = float(v)
940:         if len(sigs) < 8:
941:             unusable[lab] = f"signal '{sig_name}' 不可用或样本过少 (n={len(sigs)})"
942:             continue
943:         pos_thr, neg_thr, y = extreme_bin_labels(sigs, top_q)
944:         pos = sum(1 for v in y.values() if v == 1)
945:         neg = sum(1 for v in y.values() if v == 0)
946:         mid = sum(1 for v in y.values() if v is None)
947:         if pos == 0 or neg == 0:
948:             unusable[lab] = f"extreme-bin 退化 (pos={pos}, neg={neg}, mid={mid})"
949:             continue
950:         labels_out[lab] = {
951:             "signal": sig_name,
952:             "thresholds": {"pos_ge": pos_thr, "neg_le": neg_thr, "top_quantile": top_q},
953:             "counts": {"pos": pos, "neg": neg, "dropped_mid": mid, "total_with_signal": len(sigs)},
954:             "labels": {fid: (None if yv is None else int(yv)) for fid, yv in y.items()},
955:         }
956: 
957:     return {
958:         "dataset": dataset_tag,
959:         "top_quantile": top_q,
960:         "labels": labels_out,
961:         "unusable_reasons": unusable,
962:         "signals": fam_signals,
963:     }
964: 
965: 
966: def stratified_random_split(family_ids: list[str], strata: dict[str, str], test_size: float, seed: int) -> tuple[list[str], list[str]]:
967:     rng = np.random.RandomState(seed)
968:     by = defaultdict(list)
```

### split construction
- source: `run_first_pass_probing.py` (around line 961)
```
961:         "unusable_reasons": unusable,
962:         "signals": fam_signals,
963:     }
964: 
965: 
966: def stratified_random_split(family_ids: list[str], strata: dict[str, str], test_size: float, seed: int) -> tuple[list[str], list[str]]:
967:     rng = np.random.RandomState(seed)
968:     by = defaultdict(list)
969:     for fid in family_ids:
970:         by[strata.get(fid, "")].append(fid)
971:     train: list[str] = []
972:     test: list[str] = []
973:     for _, ids in by.items():
974:         ids2 = list(ids)
975:         rng.shuffle(ids2)
976:         n_test = max(1, int(round(len(ids2) * test_size)))
977:         test.extend(ids2[:n_test])
978:         train.extend(ids2[n_test:])
979:     return sorted(train), sorted(test)
980: 
981: 
982: def held_out_subfamily_splits(families: dict[str, dict[str, Any]]) -> list[tuple[str, list[str], list[str]]]:
983:     # returns list of (split_name, train_ids, test_ids)
984:     by_sf = defaultdict(list)
985:     for fid, info in families.items():
986:         by_sf[str(info.get("sub_family", ""))].append(fid)
987:     splits: list[tuple[str, list[str], list[str]]] = []
988:     all_ids = set(families.keys())
989:     for sf, test_ids in sorted(by_sf.items(), key=lambda kv: kv[0]):
990:         test = sorted(test_ids)
991:         train = sorted(list(all_ids - set(test_ids)))
992:         if len(test) >= 4 and len(train) >= 8:
993:             splits.append((f"held_out_sub_family::{sf}", train, test))
994:     return splits
995: 
996: 
997: def block_level_splits(families: dict[str, dict[str, Any]]) -> list[tuple[str, list[str], list[str]]]:
998:     by_tf = defaultdict(list)
999:     for fid, info in families.items():
1000:         by_tf[str(info.get("task_family", ""))].append(fid)
1001: 
1002:     def ids(tf_list: list[str]) -> list[str]:
1003:         out: list[str] = []
1004:         for tf in tf_list:
1005:             out.extend(by_tf.get(tf, []))
1006:         return sorted(out)
1007: 
1008:     setups = [
1009:         ("block::train_KB_RB__test_Hybrid", ["KB", "RB"], ["Hybrid"]),
1010:         ("block::train_KB__test_RB", ["KB"], ["RB"]),
1011:         ("block::train_KB__test_Hybrid", ["KB"], ["Hybrid"]),
1012:         ("block::train_RB__test_Hybrid", ["RB"], ["Hybrid"]),
1013:     ]
1014:     out: list[tuple[str, list[str], list[str]]] = []
1015:     for name, tr, te in setups:
1016:         tr_ids = ids(tr)
1017:         te_ids = ids(te)
1018:         if len(tr_ids) >= 8 and len(te_ids) >= 4:
1019:             out.append((name, tr_ids, te_ids))
1020:     return out
1021: 
1022: 
1023: def realization_splits(families: dict[str, dict[str, Any]]) -> list[tuple[str, list[str], list[str]]]:
1024:     nat = sorted([fid for fid, info in families.items() if str(info.get("mode")) == "naturalized"])
1025:     sym = sorted([fid for fid, info in families.items() if str(info.get("mode")) in {"strict_symbolic", "symbolic"}])
1026:     out: list[tuple[str, list[str], list[str]]] = []
1027:     if len(nat) >= 8 and len(sym) >= 8:
1028:         out.append(("realization::train_natural__test_symbolic", nat, sym))
1029:         out.append(("realization::train_symbolic__test_natural", sym, nat))
1030:     return out
1031: 
1032: 
1033: def _resolve_layers(store: HiddenStateStore, sample_path: str, key: str) -> list[int]:
1034:     # load one tensor
1035:     arr = store._load_file(sample_path, key)  # type: ignore[attr-defined]
1036:     if arr.ndim == 1:
1037:         return [0]
1038:     return list(range(arr.shape[0]))
1039: 
1040: 
```

### delta feature construction
- source: `run_first_pass_probing.py` (around line 1081)
```
1081:             hidden_state_key = rr.get("hidden_state_key")
1082:             uid = rr.get("uid")
1083:             layer_index = None
1084:             position_type = rr.get("position_type")
1085: 
1086:         try:
1087:             return store.get(_Row, layer)
1088:         except Exception:
1089:             return None
1090: 
1091:     def delta(fid: str, vt: str, layer: int) -> np.ndarray | None:
1092:         v1 = vec(fid, vt, layer)
1093:         v0 = vec(fid, "original", layer)
1094:         if v1 is None or v0 is None:
1095:             return None
1096:         return v1 - v0
1097: 
1098:     # Collect fids with labels and needed features
1099:     def build_xy(ids: list[str], layer: int, use_delta: bool, dv: str | None) -> tuple[np.ndarray, np.ndarray, list[str]]:
1100:         X: list[np.ndarray] = []
1101:         y: list[int] = []
1102:         kept: list[str] = []
1103:         for fid in ids:
1104:             if fid not in labels:
1105:                 continue
1106:             if use_delta:
1107:                 if not dv:
1108:                     continue
1109:                 v = delta(fid, dv, layer)
1110:             else:
1111:                 v = vec(fid, variant, layer)
1112:             if v is None:
1113:                 continue
1114:             X.append(v.astype(np.float32))
1115:             y.append(int(labels[fid]))
1116:             kept.append(fid)
1117:         if not X:
1118:             raise ValueError("no features")
1119:         return np.stack(X, 0), np.array(y, dtype=np.int64), kept
1120: 
1121:     # Fit scaler on train
1122:     from sklearn.preprocessing import StandardScaler
1123: 
1124:     layer_results: dict[int, list[dict[str, Any]]] = defaultdict(list)
1125:     best_pick = None
1126: 
1127:     out_dir = out_root / dataset_tag / position_key / feature_mode / label_name / split_name
1128: 
1129:     # Resume/skip: if this exact run already produced a summary, reuse it.
1130:     summary_path = out_dir / "summary.json"
1131:     if summary_path.exists():
1132:         try:
1133:             with open(summary_path, "r", encoding="utf-8") as f:
1134:                 prev = json.load(f)
1135:             # Only skip successful runs. "unusable" may become usable after bugfixes.
1136:             if isinstance(prev, dict) and prev.get("status") == "ok":
1137:                 return prev
1138:         except Exception:
1139:             pass
1140: 
1141:     _ensure_dir(out_dir)
1142: 
1143:     per_layer_rows_json: list[dict[str, Any]] = []
1144:     pred_rows_best: list[dict[str, Any]] = []
1145:     best_layer = None
1146:     best_score = -1.0
1147: 
1148:     for layer in layers:
1149:         try:
1150:             X_tr, y_tr, kept_tr = build_xy(train_ids, layer, use_delta=(delta_variant is not None), dv=delta_variant)
1151:             X_te, y_te, kept_te = build_xy(test_ids, layer, use_delta=(delta_variant is not None), dv=delta_variant)
1152:         except Exception:
1153:             continue
1154: 
1155:         # Degenerate splits: cannot fit a classifier with a single training class.
1156:         # Also skip single-class test splits (macro-F1 becomes uninformative).
1157:         if len(np.unique(y_tr)) < 2:
1158:             continue
1159:         if len(np.unique(y_te)) < 2:
1160:             continue
```

### metadata-only classifier (handoff script)
- source: handoff-only (not committed to repo); shown for exact baseline definition
```
# Handoff-only metadata baseline (not in repo):
# Allowed features: task_family / sub_family / mode / answer_type

enc = OneHotEncoder(handle_unknown='ignore', sparse_output=False)
X_tr = enc.fit_transform(onehot_X(meta_lookup, train_ids))
X_te = enc.transform(onehot_X(meta_lookup, test_ids))

f1s = []
for seed in [0,1,2,3,4]:
    clf = LogisticRegression(class_weight='balanced', random_state=seed, max_iter=1000, solver='lbfgs')
    clf.fit(X_tr, y_tr)
    pred = clf.predict(X_te)
    f1s.append(f1_score(y_te, pred, average='macro'))

metadata_f1_mean = float(np.mean(f1s))
metadata_f1_std  = float(np.std(f1s, ddof=0))
```

### third-pass hidden vs metadata comparison (transfer label alignment)
- source: `run_first_pass_probing.py` (around line 1795)
```
1795:                         rows=rows_both,
1796:                         labels=labels_pref,
1797:                         train_ids=te_ids,
1798:                         test_ids=tr_ids,
1799:                         variant="original",
1800:                         delta_variant=None,
1801:                         seeds=seeds,
1802:                         split_name=f"mcq_transfer::train_mcq__test_nonmcq::{pos}",
1803:                         position_key=pos,
1804:                         feature_mode="absolute::h_original",
1805:                         label_name=lab,
1806:                         task_is_multiclass=False,
1807:                     )
1808:                 )
1809: 
1810:     # cross-dataset transfer (probe_ready <-> gpt_test)
1811:     # 用 train dataset 的阈值对齐 label（避免 quantile 语义漂移）。
1812:     def transfer_labels(train_blob: dict[str, Any], test_blob: dict[str, Any], label: str) -> tuple[dict[str, int], dict[str, int], str] | None:
1813:         if label not in train_blob.get("labels", {}):
1814:             return None
1815:         sig_name = train_blob["labels"][label]["signal"]
1816:         thr = train_blob["labels"][label]["thresholds"]
1817:         pos_thr = float(thr["pos_ge"])
1818:         neg_thr = float(thr["neg_le"])
1819:         def assign(blob: dict[str, Any]) -> dict[str, int]:
1820:             out = {}
1821:             for fid, sd in blob.get("signals", {}).items():
1822:                 v = sd.get(sig_name)
1823:                 if not isinstance(v, (int, float)):
1824:                     continue
1825:                 fv = float(v)
1826:                 if fv >= pos_thr:
1827:                     out[fid] = 1
1828:                 elif fv <= neg_thr:
1829:                     out[fid] = 0
1830:             return out
1831:         y_tr = assign(train_blob)
1832:         y_te = assign(test_blob)
1833:         if len(set(y_tr.values())) < 2 or len(set(y_te.values())) < 2:
1834:             return None
1835:         return y_tr, y_te, sig_name
1836: 
1837:     if (not args.no_transfers) and ("probe_ready" in want_datasets) and ("gpt_test" in want_datasets):
1838:         for pos in ("final_input", "pre_answer"):
1839:             rows_pr = _read_jsonl(meta_root / f"probe_ready.{pos}.jsonl")
1840:             rows_gt = _read_jsonl(meta_root / f"gpt_test.{pos}.jsonl")
1841: 
1842:             rows_pr_p = _prefix_rows(rows_pr, "probe_ready")
1843:             rows_gt_p = _prefix_rows(rows_gt, "gpt_test")
1844:             rows_both = rows_pr_p + rows_gt_p
1845: 
1846:             # only use original for features in transfer
1847:             pr_ids = sorted({r["family_id"] for r in rows_pr if r.get("variant") == "original"})
1848:             gt_ids = sorted({r["family_id"] for r in rows_gt if r.get("variant") == "original"})
1849:             for lab in probe_labels:
1850:                 t1 = transfer_labels(labels_pr, labels_gt, lab)
1851:                 if t1 is not None:
1852:                     y_tr, y_te, sig = t1
1853:                     tr_base = [fid for fid in pr_ids if fid in y_tr]
1854:                     te_base = [fid for fid in gt_ids if fid in y_te]
1855:                     tr = [f"probe_ready::{fid}" for fid in tr_base]
1856:                     te = [f"gpt_test::{fid}" for fid in te_base]
1857:                     labels_pref = {f"probe_ready::{fid}": y_tr[fid] for fid in tr_base}
1858:                     labels_pref.update({f"gpt_test::{fid}": y_te[fid] for fid in te_base})
1859:                     if len(tr) >= 8 and len(te) >= 8:
1860:                         results_all.append(
1861:                             run_layerwise_probe(
1862:                                 dataset_tag="cross_dataset_transfer_v2",
1863:                                 out_root=out_root,
1864:                                 store=store,
1865:                                 rows=rows_both,
1866:                                 labels=labels_pref,
1867:                                 train_ids=tr,
1868:                                 test_ids=te,
1869:                                 variant="original",
1870:                                 delta_variant=None,
1871:                                 seeds=seeds,
1872:                                 split_name=f"train_probe_ready__test_gpt_test::{lab}::{pos}",
1873:                                 position_key=pos,
1874:                                 feature_mode="absolute::h_original",
```

### MCQ transfer selection
- source: `run_first_pass_probing.py` (around line 1757)
```
1757:                 y_raw = lab_defs[lab]["labels"]
1758:                 y = {fid: int(v) for fid, v in y_raw.items() if v is not None}
1759:                 # intersect
1760:                 tr_base = [fid for fid in sym_non if fid in y]
1761:                 te_base = [fid for fid in sym_mcq if fid in y]
1762:                 if len(tr_base) < 8 or len(te_base) < 8:
1763:                     continue
1764: 
1765:                 tr_ids = [f"nonmcq::{fid}" for fid in tr_base]
1766:                 te_ids = [f"mcq::{fid}" for fid in te_base]
1767:                 labels_pref = {f"nonmcq::{fid}": y[fid] for fid in tr_base}
1768:                 labels_pref.update({f"mcq::{fid}": y[fid] for fid in te_base})
1769: 
1770:                 results_all.append(
1771:                     run_layerwise_probe(
1772:                     dataset_tag="mcq_transfer_v2",
1773:                         out_root=out_root,
1774:                         store=store,
1775:                         rows=rows_both,
1776:                         labels=labels_pref,
1777:                         train_ids=tr_ids,
1778:                         test_ids=te_ids,
1779:                         variant="original",
1780:                         delta_variant=None,
1781:                         seeds=seeds,
1782:                         split_name=f"mcq_transfer::train_nonmcq__test_mcq::{pos}",
1783:                         position_key=pos,
1784:                         feature_mode="absolute::h_original",
1785:                         label_name=lab,
1786:                         task_is_multiclass=False,
1787:                     )
1788:                 )
1789:                 # reverse: train MCQ -> test non-MCQ
1790:                 results_all.append(
1791:                     run_layerwise_probe(
1792:                     dataset_tag="mcq_transfer_v2",
1793:                         out_root=out_root,
1794:                         store=store,
1795:                         rows=rows_both,
1796:                         labels=labels_pref,
1797:                         train_ids=te_ids,
1798:                         test_ids=tr_ids,
1799:                         variant="original",
1800:                         delta_variant=None,
1801:                         seeds=seeds,
1802:                         split_name=f"mcq_transfer::train_mcq__test_nonmcq::{pos}",
1803:                         position_key=pos,
1804:                         feature_mode="absolute::h_original",
1805:                         label_name=lab,
1806:                         task_is_multiclass=False,
1807:                     )
1808:                 )
1809: 
1810:     # cross-dataset transfer (probe_ready <-> gpt_test)
1811:     # 用 train dataset 的阈值对齐 label（避免 quantile 语义漂移）。
1812:     def transfer_labels(train_blob: dict[str, Any], test_blob: dict[str, Any], label: str) -> tuple[dict[str, int], dict[str, int], str] | None:
1813:         if label not in train_blob.get("labels", {}):
1814:             return None
1815:         sig_name = train_blob["labels"][label]["signal"]
1816:         thr = train_blob["labels"][label]["thresholds"]
1817:         pos_thr = float(thr["pos_ge"])
1818:         neg_thr = float(thr["neg_le"])
1819:         def assign(blob: dict[str, Any]) -> dict[str, int]:
1820:             out = {}
1821:             for fid, sd in blob.get("signals", {}).items():
1822:                 v = sd.get(sig_name)
1823:                 if not isinstance(v, (int, float)):
1824:                     continue
1825:                 fv = float(v)
1826:                 if fv >= pos_thr:
1827:                     out[fid] = 1
1828:                 elif fv <= neg_thr:
1829:                     out[fid] = 0
1830:             return out
1831:         y_tr = assign(train_blob)
1832:         y_te = assign(test_blob)
1833:         if len(set(y_tr.values())) < 2 or len(set(y_te.values())) < 2:
1834:             return None
1835:         return y_tr, y_te, sig_name
1836: 
```

## 8. Known risks

- missing summaries (部分 summary.json 不存在或 status!=ok)
- label imbalance / degenerate labels (见 Label distribution summary)
- absolute-only result (部分 setting 仅 absolute::h_original)
- suspicious MCQ (仅保留少量 mcq rows 且 is_mcq=true)
- old cross_dataset_transfer unusable (存在旧目录的 unusable 结果；本包不纳入 CSV 关键行)
- threshold-aligned label ambiguity (跨数据集阈值对齐可能导致解释歧义)

